Thank you for downloading.

The text below states how to install the text file.

	If you have downloaded the game on steam (which you probably have), rightclick on the game in the list of games, 
	click "Properies...", then "Local Files", then "Browse...", then click on the "cryoffear" folder and put the file in it.

	Alternativly, you can go to where the folder is located, it is usually at C:\Program Files (x86)\Steam\steamapps\common\common\Cry of Fear\cryoffear


If you are having trouble, head on over to the discord server: https://discord.com/invite/xbDbthD78p or ask someone on the Cry of Fear speedrun.com forum.